let num1 =  Number(prompt("Enter the first operand: "));
let num2 =  Number(prompt("Enter the second operand: "));
let result;
function Add(){
result = num1+num2;
alert("The result of addition is: "+result)
}
Add();

function Sub(){
    result = num1-num2;
    alert("The result of Subtraction is: "+result)
    }
    Sub();

    function Multi(){
        result = num1*num2;
        alert("The result of Multiplication is: "+result)
        }
        Multi();

        function Divide(){
            result = num1/num2;
            alert("The result of Division is: "+result)
            }
            Divide();

            function Mod(){
                result = num1%num2;
                alert("The result of Modulus is: "+result)
                }
                Mod();



        
